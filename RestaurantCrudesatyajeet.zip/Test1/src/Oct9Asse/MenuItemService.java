package Oct9Asse;
import java.util.Stack;
//satyajeet
public class MenuItemService {
    private Stack<MenuItem> menuStack = new Stack<>();
    
    public void addMenuItem(MenuItem item) {
        menuStack.push(item);
        System.out.println("Menu item added successfully!");
    }
    
    public void viewAllMenuItems() {
        if (menuStack.isEmpty()) {
            System.out.println("No menu items available!");
            return;
        }
        System.out.println("\n========== ALL MENU ITEMS ==========");
        for (int i = menuStack.size() - 1; i >= 0; i--) {
            System.out.println(menuStack.get(i));
        }
    }
    
    // Search - Find menu item by ID
    public MenuItem findById(int id) {
        for (MenuItem item : menuStack) {
            if (item.getId() == id) {
                return item;
            }
        }
        return null;
    }
    
    public void updateMenuItem(int id, String name, String category, double price) {
        MenuItem item = findById(id);
        if (item != null) {
            item.setName(name);
            item.setCategory(category);
            item.setPrice(price);
            System.out.println("Menu item updated successfully!");
        } else {
            System.out.println("Menu item not found!");
        }
    }
    
    public void deleteMenuItem(int id) {
        MenuItem item = findById(id);
        if (item != null) {
            menuStack.remove(item);
            System.out.println("Menu item deleted successfully!");
        } else {
            System.out.println("Menu item not found!");
        }
    }
    
    public void deleteLastMenuItem() {
        if (menuStack.isEmpty()) {
            System.out.println("Stack is empty! No items to delete.");
        } else {
            MenuItem item = menuStack.pop();
            System.out.println("Removed: " + item);
        }
    }
}

