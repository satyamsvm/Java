package Oct9Asse;
import java.util.Scanner;

public class RestaurantCrudApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MenuItemService service = new MenuItemService();
        int choice;
        
        do {
            System.out.println("\n========== RESTAURANT MENU MANAGEMENT (Stack) ==========");
            System.out.println("1. Add Menu Item");
            System.out.println("2. View All Menu Items");
            System.out.println("3. Search Menu Item by ID");
            System.out.println("4. Update Menu Item");
            System.out.println("5. Delete Menu Item by ID");
            System.out.println("6. Delete Last Item (Pop)");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            
            switch (choice) {
                case 1 -> {
                    System.out.print(" Item ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print(" Item Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Category (Appetizer/Main Course/Dessert/Beverage): ");
                    String category = sc.nextLine();
                    System.out.print("enter price: ");
                    double price = sc.nextDouble();
                    service.addMenuItem(new MenuItem(id, name, category, price));
                }
                case 2 -> service.viewAllMenuItems();
                case 3 -> {
                    System.out.print("enter item ID for search: ");
                    int id = sc.nextInt();
                    MenuItem item = service.findById(id);
                    if (item != null)
                        System.out.println(item);
                    else
                        System.out.println("Menu item not found!");
                }
                case 4 -> {
                    System.out.print("Enter Item ID to update: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter New Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter New Category: ");
                    String category = sc.nextLine();
                    System.out.print("Enter New Price: ");
                    double price = sc.nextDouble();
                    service.updateMenuItem(id, name, category, price);
                }
                case 5 -> {
                    System.out.print("Enter Item ID to delete: ");
                    int id = sc.nextInt();
                    service.deleteMenuItem(id);
                }
                case 6 -> service.deleteLastMenuItem();
                case 7 -> System.out.println("Exiting... Thank you!");
                default -> System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 7);
        
        sc.close();
    }
}
